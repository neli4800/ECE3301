#define D1_RED     PORTEbits.RE0       // Defines D1 RED as 
#define D1_GREEN   PORTEbits.RE1       // DDefines D1 GREEN  
#define D1_BLUE    PORTEbits.RE2       // Defines D1 BLUE  

#define D2_RED     PORTBbits.RB3       // Defines D1 RED as 
#define D2_GREEN   PORTBbits.RB4       // DDefines D1 GREEN  
#define D2_BLUE    PORTBbits.RB5       // Defines D1 BLUE  


#define KEY_PRESSED  PORTDbits.RD3      // Defines EWLT_GREEN as 

 
#define D3_RED    PORTDbits.RD4        // Defines D1 RED as 
#define D3_GREEN   PORTDbits.RD5       // Defines D1 RED as 
#define D3_BLUE   PORTDbits.RD6         // Defines D1 RED as  





