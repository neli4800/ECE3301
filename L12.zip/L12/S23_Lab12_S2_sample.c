#include <stdio.h>
#include <stdlib.h>
#include <xc.h>
#include <math.h>
#include <p18f4620.h>
#include <usart.h>
#include <string.h>
#include "main.h"
#include "ST7735_TFT.h"
#include "Interrupt.h"
#include "I2C.h"
#include "I2C_Support.h" 
#include "Fan_Support.h"
#include "utils.h"

#pragma config OSC = INTIO67
#pragma config WDT = OFF
#pragma config LVP = OFF
#pragma config BOREN = OFF

char tempSecond = 0xff;
char second = 0x00;
char minute = 0x00;
char hour = 0x00;
char dow = 0x00;
char day = 0x00;
char month = 0x00;
char year = 0x00;
char setup_second, setup_minute, setup_hour, setup_day, setup_month, setup_year;
char alarm_second, alarm_minute, alarm_hour, alarm_date;
char setup_alarm_second, setup_alarm_minute, setup_alarm_hour;

#define _XTAL_FREQ  8000000             // Set operation for 8 Mhz


void Initialize_Screen();
void wait_one_sec();

extern unsigned long long Nec_code;
extern unsigned char Nec_State = 0;

short Nec_OK = 0;


char Nec_Button;
char FAN;
char duty_cycle = 50;



// colors
#define RD               ST7735_RED
#define BU               ST7735_BLUE
#define GR               ST7735_GREEN
#define MA               ST7735_MAGENTA
#define BK               ST7735_BLACK

#define Circle_Size     20              // Size of Circle for Light
#define Circle_X        60              // Location of Circle
#define Circle_Y        80              // Location of Circle
#define Text_X          52
#define Text_Y          77
#define TS_1            1               // Size of Normal Text
#define TS_2            2               // Size of Big Text



char buffer[31];                        // general buffer for display purpose
char *nbr;                              // general pointer used for buffer
char *txt;

char array1[21]={0xa2, 0x62, 0xe2, 0x22, 0x02, 0xc2, 0xe0, 0xa8, 0x90, 0x68, 0x98, 0xb0, 0x30, 0x18, 0x7a, 0x10, 0x38, 0x5a, 0x42, 0x4a, 0x52};
char txt1[21][4] ={"CH-\0","CH \0","CH+\0","PRV\0","NXT\0","PP \0","VL-\0","VL+\0","EQ \0"," 0 \0","100\0","200\0"," 1 \0"," 2 \0"," 3 \0"," 4 \0"," 5 \0"," 6 \0"," 7 \0"," 8 \0"," 9 \0"};
										// add more value into this array
int color[21]={RD,RD,RD,BU,BU,GR,BU,BU,MA,BK,BK,BK,BK,BK,BK,BK,BK,BK,BK,BK,BK};					// add more value into this array



int D1[21] = {1, 1, 1, 6, 6, 2, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
int D2[21] = {0, 0, 0, 0, 0, 0, 0, 0x20, 0x28, 0x38, 0x38, 0x38, 0x38, 0x38, 0, 0, 0, 0, 0, 0, 0};
int D3[21] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0x70, 0x70, 0x70, 0x70, 0x70, 0x70, 0x70};

void putch (char c)
{
    while (!TRMT);
    TXREG = c;
}

void init_UART()
{
    OpenUSART (USART_TX_INT_OFF & USART_RX_INT_OFF &
    USART_ASYNCH_MODE & USART_EIGHT_BIT & USART_CONT_RX &
    USART_BRGH_HIGH, 25);
    OSCCON = 0x60;
}



void main()
{
    init_UART();
    OSCCON = 0x70;                          // 8 Mhz
    nRBPU = 0;                              // Enable PORTB internal pull up resistor
    TRISA = 0x00;                           //
	TRISB = 0x07;							//
    TRISC = 0x01;                           // PORTC as input
    TRISD = 0x00;                           // PORTD as output
    TRISE= 0X00;                            // PORTE as output
    ADCON1 = 0x0F;                          //  
    
    Initialize_Screen();					//
    T3CON = 0x03;
	
    I2C_Init(100000);                       //
    DS1621_Init();                          //
    
    Init_INTERRUPT();
    
    
    TMR1H = 0;                              // Reset Timer1
    TMR1L = 0;                              //
    PIR1bits.TMR1IF = 0;                    // Clear timer 1 interrupt flag
    PIE1bits.TMR1IE = 1;                    // Enable Timer 1 interrupt
    INTCONbits.PEIE = 1;                    // Enable Peripheral interrupt
    INTCONbits.GIE = 1;                     // Enable global interrupts
    Nec_OK = 0;                             // Clear flag
    Nec_code = 0x0;                         // Clear code
    PORTD = PORTD & 7;
    PORTB = PORTB & 4;
    PORTE = PORTE & 0;
    
    
    DS3231_Setup_Time();    
    FAN_EN = 0;                             // Enable fan to off
    FAN_PWM = 1;                            // Fan pwm is set on
//    char duty_cycle = 50;
    do_update_pwm(duty_cycle) ;             // updates duty cycle
    
    while(1)
    {
 
        DS3231_Read_Time();   // calls DS3231_Read_Time function
        
        if(tempSecond != second)                // prints the seconds, minutes, hours minutes day, year
        {
        tempSecond = second;                    
        signed char tempC = DS1621_Read_Temp();       // temp in C
        signed char tempF = (tempC * 9 / 5) + 32;    // temp in F
        int rpm = get_RPM();                        // calls the get_RPM function into an integer
        Set_DC_RGB(duty_cycle);                     // D1 will update with the duty cycle
        Set_RPM_RGB(rpm);                           // D2 will update with the rpm
        printf ("%02x:%02x:%02x %02x/%02x/%02x",hour,minute,second,month,day,year);  // prints out the hour, minutes,seconds, month, day, year
        printf (" Temperature = %d degreesC = %d degreesF\r\n", tempC, tempF);      //  prints the temp in C and F
        printf ("RPM = %d dc = %d\r\n", rpm, duty_cycle);                           //  print out the duty cycle and rpm
        } 
        
        if (Nec_OK == 1)
        {
            
            Nec_OK = 0;
            

            Enable_INT_Interrupt();
            printf ("NEC_Button = %x \r\n", Nec_Button);  
			
            char found = 0xff;
         
                // loop to search for match of Nec_Button with entry of array1
            for(char i = 0;i <= 20 ; i++)
            {
                if(Nec_Button == array1[i])
                {
                    found = i; 
                    
                    if(i == 0)          // if button 0 pressed call DS3231_Setup_Time function  
            {
                DS3231_Setup_Time();
            }
            
            if(i == 5)          // if button 5 pressed call Toggle_Fan function  
            {
                Toggle_Fan();
            }
            
            if(i == 6)          // if button 6 pressed call Decrease_Speed function  
            {
                Decrease_Speed();
            }
            
            if(i == 7)          // if button 7 pressed call Increase_Speed function  
            {
                Increase_Speed();
            }
                }    

            }
            
            
            
            
            if (found != 0xff) 
            {

                
				printf ("Key Location = %d \r\n\n", found); 
                fillCircle(Circle_X, Circle_Y, Circle_Size, color[found]); 
                drawCircle(Circle_X, Circle_Y, Circle_Size, ST7735_WHITE);  
                drawtext(Text_X, Text_Y, txt1[found], ST7735_WHITE, ST7735_BLACK,TS_1);
				
				//  code here to output color for the three RGB LEDs
                PORTD = PORTD & 7;
                PORTB = PORTB & 4;
                PORTE = PORTE & 0;
                PORTE = PORTE + D1[found];
                PORTB = PORTB + D2[found];
                PORTD = PORTD + D3[found];
                
				KEY_PRESSED = 1;        // add code to turn on KEY PRESSED LEDs
				Activate_Buzzer();      // generate beep tone
				wait_one_sec();         // wait 1 second
				Deactivate_Buzzer();    // remove beep tone
                do_update_pwm(duty_cycle);   // updates the duty_cycle
				KEY_PRESSED = 0;        // turn off KEY PRESSED
            
            }
        }
    }
    }


void wait_one_sec()
{
    for (int k=0;k<30000;k++);
}

void Initialize_Screen()
{
    LCD_Reset();
    TFT_GreenTab_Initialize();
    fillScreen(ST7735_BLACK);
  
    /* TOP HEADER FIELD */
    txt = buffer;
    strcpy(txt, "ECE3301L Sp23/S2/T01");  
    drawtext(2, 2, txt, ST7735_WHITE, ST7735_BLACK, TS_1);

    strcpy(txt, "LAB 12 ");  
    drawtext(50, 10, txt, ST7735_WHITE, ST7735_BLACK, TS_1);
}


