#include <p18f4620.h>
#include "Fan_Support.h"
#include "stdio.h"

extern char FAN;
extern char duty_cycle;

int get_RPM()       // gets the rpm from the fan
{
    int RPS = TMR3L / 2;
    TMR3L = 0;
    return (RPS * 60);
}

void Toggle_Fan()   // turns the fan on and off
{
    if(FAN == 0){
        Turn_On_Fan();
    }
    else{
        Turn_Off_Fan();
    }
}

void Turn_Off_Fan()     // turns the fan off 
{
    FAN = 0;
    FAN_EN = 0;
    FAN_EN_LED = 0;
}

void Turn_On_Fan()      // turns the fan on
{
    FAN = 1;
    do_update_pwm(duty_cycle);
    FAN_EN = 1;
    FAN_EN_LED = 1;
}

void Increase_Speed()       // increases the speed of the fan by 5 and will not go over 100
{
      if(duty_cycle == 100){
            Do_Beep();
            Do_Beep();
            do_update_pwm(duty_cycle);
        }else{
            duty_cycle = duty_cycle + 5;
            do_update_pwm(duty_cycle);
        }
  


}

void Decrease_Speed()       // decreases the speed of the fan by 5 and will not go below 0
{
    if(duty_cycle == 0){
        Do_Beep();
        Do_Beep();
        do_update_pwm(duty_cycle);
    }else{
        duty_cycle = duty_cycle - 5;
        do_update_pwm(duty_cycle);
    }
 
}


void Set_DC_RGB(int duty_cycle)     // sets the RGD  LED for D1
{
    int result = duty_cycle / 10;
    if(result >= 7) PORTE = 7;
    else PORTE = result;    
}


void Set_RPM_RGB(int rpm)   // sets the RGB LED for D2
{
    if (rpm == 0) PORTB = 0;
    if (rpm >= 3000) PORTB = 0x31;
    if (rpm > 0 && rpm < 3000) PORTB = ((rpm / 500)+1) << 3;
    
}

