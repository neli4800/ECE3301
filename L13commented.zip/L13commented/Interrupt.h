void Init_Interrupt();
void Enable_INT_Interrupt();
void interrupt high_priority chkisr(void) ;
void INT2_isr(void);
void TIMER1_isr(void);
void Reset_Nec_State();



