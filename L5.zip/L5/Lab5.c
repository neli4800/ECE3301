#include <p18f4620.h>
#include <stdio.h>
#include <math.h>
#include <usart.h>

#pragma config OSC = INTIO67
#pragma config WDT=OFF
#pragma config LVP=OFF
#pragma config BOREN =OFF

#define delay 5                                 // A macro that defines the value of delay as 5

#define D1_RED PORTCbits.RC0                    // output pins for driving LEDs
#define D1_GREEN PORTCbits.RC1                  // output pins for driving LEDs
#define D1_BLUE PORTCbits.RC2                   // output pins for driving LEDs

#define D2_RED PORTCbits.RC3                    // output pins for driving LEDs
#define D2_GREEN PORTCbits.RC4                  // output pins for driving LEDs
#define D2_BLUE PORTCbits.RC5                   // output pins for driving LEDs

#define D3_RED PORTEbits.RE0                    // output pins for driving LEDs
#define D3_BLUE PORTEbits.RE1                   // output pins for driving LEDs

void SET_ADCON0(char);                          // Function prototypes
void INIT_ADC(void);                            // Function prototypes
void init_UART(void);                           // Function prototypes

void set_D1_color(int tempF) {                  // set the values of three pins (D1_RED, D1_GREEN, D1_BLUE) based on the temperature range
  if (tempF < 40) {
    D1_RED = 0;
    D1_GREEN = 0;
    D1_BLUE = 0;
  } else if (tempF >= 40 && tempF <49) {
    D1_RED = 1;
    D1_GREEN = 0;
    D1_BLUE = 0;
  } else if (tempF >= 50 && tempF <59) {
    D1_RED = 0;
    D1_GREEN = 1;
    D1_BLUE = 0;
  } else if (tempF >= 60 && tempF <69) {
    D1_RED = 0;
    D1_GREEN = 0;
    D1_BLUE = 1;
  } else if (tempF >= 70 && tempF <71) {
    D1_RED = 1;
    D1_GREEN = 0;
    D1_BLUE = 1;
  } else if (tempF >= 72 && tempF <73) {
    D1_RED = 0;
    D1_GREEN = 1;
    D1_BLUE = 1;
  } else {
    D1_RED = 1;
    D1_GREEN = 1;
    D1_BLUE = 1;
  }
}

void set_D3_color(int voltage) {                                       //set the values of two pins (D3_RED, D3_BLUE) based on the voltage range              
  if (voltage < 2600) {
    D3_RED = 0;
    D3_BLUE = 0;
  } else if (voltage >= 2600 && voltage < 3000) {
    D3_RED = 1;
    D3_BLUE = 0;
  } else if (voltage >= 3000 && voltage <3300) {
    D3_RED = 0;
    D3_BLUE = 1;
  } else {
    D3_RED = 1;
    D3_BLUE = 1;
  }
}

char array[10] = {0x01,0x4F,0x12,0x06,0x4C,0x24,0x20,0x0F,0x00,0x04}; // array for lighting up the display

void init_UART()                                                      // to print out teraterm
{
 OpenUSART (USART_TX_INT_OFF & USART_RX_INT_OFF &
USART_ASYNCH_MODE & USART_EIGHT_BIT & USART_CONT_RX &
USART_BRGH_HIGH, 25);
 OSCCON = 0x60;
}
void putch (char c)                                                 // sends char to UART
{
 while (!TRMT);
 TXREG = c;
} 

void Delay_One_Sec()                                               //Delay Function
{
    for (int j=0; j<17000; j++);                                   //For loop to implement Delay
    
}

void DO_DISPLAY_7SEG_Upper(char digit)                             //Function to handle the 7Seg Lower digit
{                                              
    PORTB = array[digit];                                          //Handling the tens place                                        // sets both to one
}

void DO_DISPLAY_7SEG_Lower(char digit)                             //Function to handle the 7Seg Upper digit
{
    PORTD = array[digit];                                          //Handling the ones place
}

void INIT_ADC(void)
{
    ADCON0=0x01;                                                   // select channel AN0, and turn on the ADC subsystem
    ADCON1=0x1B ;                                                  // select pins AN0 through AN3 as analog signal, VDD-VSS as reference voltage
    ADCON2=0xA9;                                                   // right justify the result. Set the bit conversion time (TAD) and acquisition time
}

void INIT_TRIS(void)                                                // TRIS registers, which control the direction of data flow for each pin
{
    TRISA = 0x0F;                                                   // stores data
    TRISB = 0x00;                                                   // set for output
    TRISC = 0x00;                                                   // set for output
    TRISD = 0x00;                                                   // set for output
    TRISE = 0x00;                                                   // set for output
}

unsigned int GET_FULL_ADC(void)
{
    int result;
    ADCON0bits.GO = 1;                                              // Start Conversion
    while(ADCON0bits.DONE == 1);                                    // Wait for conversion to be completed (DONE=0)
    result = (ADRESH * 0x100) + ADRESL;                             // Combine result of upper byte and lower byte
    return result;                                                  // return the most significant 8- bits of the result.
}

void SET_ADCON0(char AN_pin)                                        // Set ADC channels
{
    ADCON0 = (AN_pin * 4) + 1;
}

set_D2_color(int temp)                                              // D2, based on the temperature value passed in
{
    char NT = temp/10;
    if (NT >= 7)
        NT = 7;
    PORTC = NT<< 3;
}


void main(void)
{
    init_UART();                                                    // initializes the UART
    INIT_ADC();                                                     // initializes the ADC
    INIT_TRIS();                                                    // initializes the TRIS
    while(1)                                                        // infinite loop
    {
        SET_ADCON0(0);                                              // sets the ADCON0 register to 0
        int num_step = GET_FULL_ADC();                              // input value from AN0 and stores it as an integer value 
        float voltage_mv = num_step * 4.0;                          // calculates the voltage in millivolts by multiplying the num_step value   
        float temperature_C = (1035.0 - voltage_mv) / 5.50;         // calculates the temperature in Celsius using the voltage
        float temperature_F = (1.80 * temperature_C) + 32.0;        // converts the temperature from Celsius to Fahrenheit
        int tempF = (int) temperature_F;                            // converts the temperature_F value to an integer value
        char U = tempF / 10;                                        // Extract the tens  digits of tempF
        char L = tempF % 10;                                        // Extract the ones digits of tempF
        DO_DISPLAY_7SEG_Upper(U);                                   // U value displayed on the upper segment
        DO_DISPLAY_7SEG_Lower(L);                                   // L value displayed on the lower segment
        Delay_One_Sec();                                            // function causes a delay of one second
        
        
        set_D2_color(tempF);                                        // sets D2 LED colors
        set_D1_color(tempF);                                        // sets D1 LED colors
        
        Delay_One_Sec();                                            // function causes a delay of one second
        
                                                
        
        Delay_One_Sec();                                            // function causes a delay of one second
        
        SET_ADCON0(1);                                              // sets the ADCON0 register to 1
        int light_step = GET_FULL_ADC();                            // input value from AN1 and stores it as an integer value 
        float voltage_light = (light_step * 4.0);                   // calculates the voltage in millivolts by multiplying the num_step value 
        int voltagel = (int) voltage_light;                         // converts voltage to an integer 
        set_D3_color(voltagel);                                     // set D3 LED colors
        Delay_One_Sec();                                            // function causes a delay of one second

        printf ("Steps = %d \r\n", num_step);                       // prints out num steps to TeraTerm
        printf ("Voltage = %.1f mv \r\n", voltage_mv);              // prints out voltage of ADCON 0 to TeraTerm
        printf ("Temperature = %d F \r\n\n", tempF);                // prints out temperature to TeraTerm
        printf ("Light Voltage = %.1f mv \r\n", voltage_light);     // prints out voltage of ADCON 1 to TeraTEerm
        
    }

}






