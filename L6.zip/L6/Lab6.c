#include <p18f4620.h>
#include <stdio.h>
#include <math.h>
#include <usart.h>
#pragma config OSC = INTIO67
#pragma config WDT=OFF
#pragma config LVP=OFF
#pragma config BOREN =OFF

#define DP PORTDbits.RD7                                                    //labeling the port pin for the SEVEN SEG DISPLAY

//int num_step;	
//float volt;
		
int array[10] = {0x01,0x4F,0x12,0x06,0x4C,0x24,0x20,0x0F,0x00,0x04};        // array for lighting up the display


void Init_ADC(void);                                                        // Function prototypes
unsigned int GET_FULL_ADC(void);                                            // Function prototypes
void init_UART();                                                           // Function prototypes
void select_ADC_Channel(char);                                              // Function prototypes
void DO_DISPLAY7_SEG_UPPER(char);                                           // Function prototypes
void Delay_One_Sec();                                                       // Function prototypes
void DO_DISPLAY7_SEG_LOWER(char);                                           // Function prototypes

void INIT_UART()                                                            // to print out teraterm
{
 OpenUSART (USART_TX_INT_OFF & USART_RX_INT_OFF &
USART_ASYNCH_MODE & USART_EIGHT_BIT & USART_CONT_RX &
USART_BRGH_HIGH, 25);
 OSCCON = 0x60;					
} 

void putch (char c)                                                         // sends char to UART
{
 while (!TRMT);
 TXREG = c;
} 

void select_ADC_Channel(char channel)                                       // set ADC channels
{
    ADCON0 = (channel * 4) + 1;
}


void INIT_ADC(void)
{
    ADCON0=0x01;                                                            // select channel AN0, and turn on the ADC subsystem
    ADCON1=0x1B ;                                                           // select pins AN0 through AN3 as analog signal, VDD-VSS as reference voltage
    ADCON2=0xA9;                                                            // right justify the result. Set the bit conversion time (TAD) and acquisition time
}

unsigned int GET_FULL_ADC(void)
{
    int result;
    ADCON0bits.GO = 1;                                                      // Start Conversion
    while(ADCON0bits.DONE == 1);                                            // Wait for conversion to be completed (DONE=0)
    result = (ADRESH * 0x100) + ADRESL;                                     // Combine result of upper byte and lower byte
    return result;                                                          // return the most significant 8- bits of the result.
}

void INIT_TRIS(void)                                                        // TRIS registers, which control the direction of data flow for each pin
{
    TRISA = 0xFF;                                                           //set for an input
    TRISB = 0x00;                                                           // set for output
    TRISC = 0x00;                                                           // set for output
    TRISD = 0x00;                                                           // set for output
    TRISE = 0x00;                                                           // set for output
}

void DO_DISPLAY7_SEG_UPPER(char digit)                                      //Function to handle the 7Seg Upper digit
{ 
    PORTB = array[digit];                                                   //Handling the tens place
}

void DO_DISPLAY7_SEG_LOWER(char digit)                                       //Function to handle the 7Seg Lower digit
{
    PORTD = array[digit];                                                    //Handling the ones place

}

void Delay_One_Sec()                                                        //Delay Function
{
 for(int I=0; I <0xffff; I++);				
} 

void main()
{
    INIT_UART();                                                         // initializes the UART
    INIT_ADC();                                                         // initializes the ADC
    INIT_TRIS();                                                        // initializes the TRIS
    while(1)                                                            // infinite loop
    {
        select_ADC_Channel(0);                                          // sets the ADCON0 register to 0
        int num_step = GET_FULL_ADC();                                  // input value from AN0 and stores it as an integer value 
        float volt = (num_step * 4);                                    // calculates the voltage in millivolts by multiplying the num_step value								//and calculate
        int U = ((int)(volt/1000));                                     // calculates to get the ones BCD voltage
        int L = ((int)((volt/1000)*10)%10);                             // calculates to get the decimal voltage
        DP = 0;                                                         // turns on the decimal point

        DO_DISPLAY7_SEG_LOWER(L);                                       // L value displayed on the lower segment
        DO_DISPLAY7_SEG_UPPER(U);                                       // U value displayed on the upper segment

        printf ("volt = %.1f mv \r\n",volt);                            // prints the voltage to TeraTerm

        Delay_One_Sec();                                                // function causes a delay of one second
    } 

}







