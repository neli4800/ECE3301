#include<p18f4620.h>
#include<stdio.h>
#include<math.h>
#include<usart.h>
#pragma config  OSC = INTIO67
#pragma config  WDT = OFF
#pragma config  LVP = OFF
#pragma config  BOREN = OFF

#define DP PORTDbits.RD7                                                // output pins for decimal point LEDs

#define D1_RED PORTEbits.RE0                                            // output pins for driving LEDs
#define D1_GREEN PORTEbits.RE2                                          // output pins for driving LEDs

#define D2_RED PORTCbits.RC2                                            // output pins for driving LEDs
#define D2_GREEN PORTCbits.RC3                                          // output pins for driving LEDs
#define D2_BLUE PORTCbits.RC4                                           // output pins for driving LEDs

float temp, resist;
		
int array[10] = {0x01,0x4F,0x12,0x06,0x4C,0x24,0x20,0x0F,0x00,0x04};     // array of LED colors       
 
unsigned int nstep;

void INIT_UART()                                                         // to print out teraterm
{
    OpenUSART (USART_TX_INT_OFF & USART_RX_INT_OFF &
        USART_ASYNCH_MODE & USART_EIGHT_BIT & USART_CONT_RX &
        USART_BRGH_HIGH, 25);
    OSCCON = 0x60;				
}

void putch(char c)                                                      // sends char to UART
{
    while(!TRMT);
    TXREG = c;
}

void Delay_One_Sec()                                                        //Delay Function
{
 for(int I=0; I <0xffff; I++);				
} 

unsigned int Get_Full_ADC(void)
{
    int result;                                                         // Where the result is stored
    ADCON0bits.GO = 1;                                                  // Start Conversion
    while(ADCON0bits.DONE==1);                                          // Wait for conversion to be completed
    result = (ADRESH * 0x100) + ADRESL;                                 // Combine result and upper byte and 

    return result;                                                      //Return the result
}

void INIT_ADC(void)
{
    ADCON0=0x01;                                                         // select channel AN0, and turn on the ADC subsystem
    ADCON1=0x1B ;                                                        // select pins AN0 through AN3 as analog signal, VDD-VSS as reference voltage
    ADCON2=0xA9;                                                         // right justify the result. Set the bit conversion time (TAD) and acquisition time
}

void Select_ADC_Channel(char channel)                                   // set ADC channels 
{
    ADCON0 = (channel*4) + 1;
}

void INIT_TRIS(void)                                                        // TRIS registers, which control the direction of data flow for each pin
{
    TRISA = 0xFF;                                                           //set for an input
    TRISB = 0x00;                                                           // set for output
    TRISC = 0x00;                                                           // set for output
    TRISD = 0x00;                                                           // set for output
    TRISE = 0x00;                                                           // set for output
}

void Activate_Buzzer()                                                      // activates the buzzer
{
    PR2 = 0b11111001 ;
    T2CON = 0b00000101 ;
    CCPR2L = 0b01001010 ;
    CCP2CON = 0b00111100 ;
} 

void Deactivate_Buzzer()                                                    // deactivates the buzzer
{
    CCP2CON = 0x0;
    PORTCbits.RC1 = 0;
} 

void SET_D1_GREEN()                                                        // sets D1 to GREEN
{
    D1_RED = 0;
    D1_GREEN = 1;
}

void SET_D1_RED()                                                          // sets D1 to RED
{
    D1_RED = 1;
    D1_GREEN = 0;
}

void SET_D1_OFF()                                                           // sets D2 to OFF
{
    D1_RED = 0;
    D1_GREEN = 0;
}

void DO_DISPLAY_7SEG_Upper(char digit)                                      //Function to handle the 7Seg Lower digit
{                                              
    PORTB = array[digit];                                                   //Handling the tens place
}
    

void DO_DISPLAY_7SEG_Lower(char digit)                                      //Function to handle the 7Seg Lower digit
{
    PORTD = array[digit];                                                   //Handling the ones place
}

void DO_DISPLAY_D2(float T)                                                 // Display D2 LED
{
    if (T >= 80) {
        T = 70.0;
    }                                                                       // if temp is above 70, display white
    PORTC = (PORTC & 0x023) | ((int)T/10) << 2;                             // else PortC will output T/10 and 

}

void DO_BUZZER(float R)                                                     // activates or deactivates the buzzer and sets D1 LED
{
    if (R < 0.07)                                                       
    {
        Activate_Buzzer();                                                  // activate buzzer
        SET_D1_GREEN();                                                 
    } 

    else if (R >= 0.07 && R <= 0.1) {
        Deactivate_Buzzer();                                                // deactivate buzzer 
        SET_D1_RED();
    }

    else
    {
        Deactivate_Buzzer();                                                // deactivate buzzer
        SET_D1_OFF();
    }
}

void main()
{
    INIT_UART();                                                            // initializes the UART
    INIT_ADC();                                                             // initializes the ADC
    INIT_TRIS();                                                            // initializes the TRIS
           
    while(1)
    { 
        Select_ADC_Channel(2);                                              // Select Channel 2
        nstep = Get_Full_ADC();                                             // Initialize step 
        float voltage_mv = nstep * 4.0;                                     // Calculate voltage in mV
        float vL = ((voltage_mv)/(1000.0));                                 // Calculate voltage in V
        float rL = 0.1*vL/(4.096 - vL);                                     // 0.1 = rref
        int U = (int) rL/10;                                                // Extract the tens  digits rL
        int L = (int) rL  % 10;                                             // Extract the one  digits of rL
        
        DO_BUZZER(rL);                                                      // call buzzer function
        
        DO_DISPLAY_D2(rL);                                                  // sets D2 with rL
        Delay_One_Sec();                                                    // call delay function
        if (rL < 10)                                                        // check if the resistance value is less than 10
        {
            temp = rL*10;                                                   // multiply resistance by 10 and store in temp
            resist = (int) temp;                                            // convert temp to integer and store in resist
            char U = (int) rL;                                              // extract integer part of resistance and store in U
            char L = (int) ((rL - U) * 10);                                 // extract decimal part of resistance and store in L
            PORTB=array[U];                                                 // output U to the upper seven-segment display
            PORTD=array[L];                                                 // output L to the lower seven-segment display
            DO_DISPLAY_7SEG_Upper (U);                                      // turn on segments in the upper seven-segment display
            DO_DISPLAY_7SEG_Lower (L);                                      // turn on segments in the lower seven-segment display
            DP = 0;                                                         // turn off the decimal point
        }
        else
        {
            resist = (int) rL;                                              // convert resistance to integer and store in resist
            char U = (int) resist/10;                                       // extract tens digit of resist and store in U
            char L = (int) resist % 10;                                     // extract ones digit of resist and store in L
            PORTB=array[U];                                                 // output U to the upper seven-segment display
            PORTD=array[L];                                                 // output L to the lower seven-segment display
            DO_DISPLAY_7SEG_Upper (U);                                      // turn on segments in the upper seven-segment display
            DO_DISPLAY_7SEG_Lower (L);                                      // turn on segments in the lower seven-segment display
            DP = 1;                                                         // turn on the decimal point
        }        
        printf("Resistance: %f kOhm\r\n", rL);                              // print the resistance value to the serial terminal

            Delay_One_Sec();                                                // wait for one second
    }

}
