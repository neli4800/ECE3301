#include<p18f4620.h>
#include<stdio.h>
#include<math.h>
#include<usart.h>

#pragma config  OSC = INTIO67
#pragma config  WDT = OFF
#pragma config  LVP = OFF
#pragma config  BOREN = OFF

#define OFF 0
#define RED 1
#define GREEN 2
#define YELLOW 3 


#define SEC_LED PORTEbits.RE0
#define MODE_LED PORTDbits.RD7 

#define EW_RED PORTEbits.RE1
#define EW_GREEN PORTEbits.RE2

#define EWLT_RED PORTAbits.RA5
#define EWLT_GREEN PORTCbits.RC0

#define NS_RED PORTCbits.RC2
#define NS_GREEN PORTCbits.RC3

#define NSLT_RED PORTCbits.RC4
#define NSLT_GREEN PORTCbits.RC5

#define EWLT_SW PORTAbits.RA1
#define EWPED_SW PORTAbits.RA2
#define NSLT_SW PORTAbits.RA3
#define NSPED_SW PORTAbits.RA4






void Wait_Half_Second();
void Wait_One_Second();
void SET_ADCON0(char);
void Wait_N_Seconds (char);
void Set_EW(char);
void Set_EWLT(char);
void Set_NS(char);
void Set_NSLT(char);
void Wait_One_Second_With_Beep();
void Activate_Buzzer();
void Deactivate_Buzzer();



void Wait_Half_Second()
{
 T0CON = 0x02;                                                              // Timer 0, 16-bit mode, prescaler 1:8
 TMR0L = 0xDB;                                                              // set the lower byte of TMR
 TMR0H = 0x0B;                                                              // set the upper byte of TMR
 INTCONbits.TMR0IF = 0;                                                     // clear the Timer 0 flag
 T0CONbits.TMR0ON = 1;                                                      // Turn on the Timer 0
 while (INTCONbits.TMR0IF == 0);                                            // wait for the Timer Flag to be 1 for done
 T0CONbits.TMR0ON = 0;                                                      // turn off the Timer 0
} 

void Wait_One_Second_With_Beep()
{
 SEC_LED = 1;                                                               // First, turn on the SEC LED
 Activate_Buzzer();                                                         // Activate the buzzer
 Wait_Half_Second();                                                        // Wait for half second (or 500 msec)
 SEC_LED = 0;                                                               // then turn off the SEC LED
 Deactivate_Buzzer();                                                       // Deactivate the buzzer
 Wait_Half_Second();                                                        // Wait for half second (or 500 msec)
}

void Wait_One_Second()
{
 SEC_LED = 1;                                                               // First, turn on the SEC LED
 Wait_Half_Second();                                                        // Wait for half second (or 500 msec)
 SEC_LED = 0;                                                               // then turn off the SEC LED
 Wait_Half_Second();                                                        // Wait for half second (or 500 msec)
}


void Wait_N_Seconds (char seconds)                                          // pause the program execution for the specified number of seconds
{
char I;
 for (I = 0; I< seconds; I++)
 {
 Wait_One_Second();
 }
} 

void Set_EW(char color)
{
 switch (color)
 {
 case OFF: EW_RED =0;EW_GREEN=0;break;                                      // Turns off the EW LED
 case RED: EW_RED =1;EW_GREEN=0;break;                                      // Sets EW LED RED
 case GREEN: EW_RED =0;EW_GREEN=1;break;                                    // sets EW LED GREEN
 case YELLOW: EW_RED =1;EW_GREEN=1;break;                                   // sets EW LED YELLOW
 }
} 

void Set_EWLT(char color) 
{
 switch (color)
 {
 case OFF: EWLT_RED =0;EWLT_GREEN=0;break;                                  // Turns off the EWLT LED
 case RED: EWLT_RED =1;EWLT_GREEN=0;break;                                  // Sets EWLT LED RED
 case GREEN: EWLT_RED =0;EWLT_GREEN=1;break;                                // sets EWLT LED GREEN
 case YELLOW: EWLT_RED =1;EWLT_GREEN=1;break;                               // sets EWLT LED YELLOW
 }
} 

void Set_NS(char color)
{
 switch (color)
 {
 case OFF: NS_RED =0;NS_GREEN=0;break;                                      // Turns off the NS LED
 case RED: NS_RED =1;NS_GREEN=0;break;                                      // Sets NS LED RED
 case GREEN: NS_RED =0;NS_GREEN=1;break;                                    // sets NS LED GREEN
 case YELLOW: NS_RED =1;NS_GREEN=1;break;                                   // sets NS LED YELLOW
 }
} 

void Set_NSLT(char color) 
{
 switch (color)
 {
 case OFF: NSLT_RED =0;NSLT_GREEN=0;break;                                  // Turns off the NSLT LED
 case RED: NSLT_RED =1;NSLT_GREEN=0;break;                                  // Sets NSLT LED RED
 case GREEN: NSLT_RED =0;NSLT_GREEN=1;break;                                // sets NSLT LED GREEN
 case YELLOW: NSLT_RED =1;NSLT_GREEN=1;break;                               // sets NSLT LED YELLOW
 }
} 

 char array[10] = {0x01,0x4F,0x12,0x06,0x4C,0x24,0x20,0x0F,0x00,0x04};      // array for lighting up the display


void Display_Upper_Digit(char digit)                                         // display the upper digit of seven segment
{
    PORTB = array[digit];
}

void Display_Lower_Digit(char digit)                                         // display the lower digit of seven segment
{
    PORTD = array[digit];
}

void Init_ADC(void)
{
    ADCON0=0x01;                                                            // select channel AN0, and turn on the ADC subsystem
    ADCON1=0x0E;                                                            // select pins AN0 through AN3 as analog signal, VDD-VSS as
                                                                            // reference voltage
    ADCON2=0xA9;                                                            // right justify the result. Set the bit conversion time (TAD) and
                                                                            // acquisition time 
} 

void INIT_TRIS(void)                                                        // TRIS registers, which control the direction of data flow for each pin
{
    TRISA = 0x1F;                                                           //set for an input
    TRISB = 0x00;                                                           // set for output
    TRISC = 0x00;                                                           // set for output
    TRISD = 0x00;                                                           // set for output
    TRISE = 0x00;                                                           // set for output
}


void init_UART()                                                      // to print out teraterm
{
 OpenUSART (USART_TX_INT_OFF & USART_RX_INT_OFF &
USART_ASYNCH_MODE & USART_EIGHT_BIT & USART_CONT_RX &
USART_BRGH_HIGH, 25);
 OSCCON = 0x60;
}
void putch (char c)                                                 // sends char to UART
{
 while (!TRMT);
 TXREG = c;
} 

void Activate_Buzzer()                                              // activates the buzzer
{
    PR2 = 0b11111001 ;
    T2CON = 0b00000101 ;
    CCPR2L = 0b01001010 ;
    CCP2CON = 0b00111100 ;
}

void Deactivate_Buzzer()                                            // deactivates buzzer
{
 CCP2CON = 0x0;
 PORTCbits.RC1 = 0;
} 

void SET_ADCON0(char AN_pin)                                        // Set ADC channels
{
    ADCON0 = (AN_pin * 4) + 1;
}

unsigned int GET_FULL_ADC(void)
{
    int result;
    ADCON0bits.GO = 1;                                              // Start Conversion
    while(ADCON0bits.DONE == 1);                                    // Wait for conversion to be completed (DONE=0)
    result = (ADRESH * 0x100) + ADRESL;                             // Combine result of upper byte and lower byte
    return result;                                                  // return the most significant 8- bits of the result.
}

void PED_Control(char Direction, char Num_Sec)                      // controls the seven seg displays 
{                                                                   // does a count down for pedestrians on seven seg
    char count = Num_Sec - 1; 
    while (count >= 1 )
    {
        if (Direction == 0 )
        {
            Display_Upper_Digit(count);
            PORTD = 0xFF;
            Wait_One_Second_With_Beep();
            count--;
        }
        else if (Direction == 1 )
        {
            Display_Lower_Digit(count);
            PORTB = 0xFF;
            Wait_One_Second_With_Beep();
            count--;
        }
        
    }
    PORTD = 0xFF;
    PORTB = 0xFF;
    Wait_One_Second_With_Beep();
    
}




void Day_Mode()
{
    
    // Two 7-segment must be off
    PORTD = 0xFF;                                               // set lower seven seg off
    PORTB = 0xFF;                                               // set lower seven seg off
    MODE_LED = 1;                                               // sets day mode led on
    
    // Step 1                                                   // all the steps for the LED lights 
    
  Set_NS(RED);
  Set_NSLT(RED);
  Set_EWLT(RED);
  Set_EW(GREEN);

  // Step 2
  if (EWPED_SW == 1) {
    PED_Control(1,7);
    
  }

  // Step 3
  Wait_N_Seconds(7);

  // Step 4
  Set_EW(YELLOW);
  Wait_N_Seconds(2);

  // Step 5
  Set_EW(RED);

  // Step 6
  if (NSLT_SW == 1) {
    // Step 7
    Set_NSLT(GREEN);
    Wait_N_Seconds(7);

    // Step 8
    Set_NSLT(YELLOW);
    Wait_N_Seconds(2);

    // Step 9
    Set_NSLT(RED);
  }

  // Step 10
  Set_NS(GREEN);
  if (NSPED_SW == 1) {
    PED_Control(0,7);
    
  }

  // Step 11
  Set_NS(GREEN);
  Wait_N_Seconds(6);

  // Step 12
  Set_NS(YELLOW);
  Wait_N_Seconds(2);

  // Step 13
  Set_NS(RED);

  // Step 14
  if (EWLT_SW == 1) {
    // Step 15
    Set_EWLT(GREEN);
    Wait_N_Seconds(9);

    // Step 16
    Set_EWLT(YELLOW);
    Wait_N_Seconds(2);

    // Step 17
    Set_EWLT(RED);
  }

   
}

void Night_Mode()
{
    
    PORTD = 0xFF;                                           // set lower seven seg off
    PORTB = 0xFF;                                           // set upper seven seg off
    MODE_LED = 0;                                           // mode led is turned off
    
      // Step 1                                             // all the steps for the LED lights 
    
    Set_NS(RED);
    Set_NSLT(RED);
    Set_EWLT(RED);
    Set_EW(GREEN);

       // Step 2
    Wait_N_Seconds(8);

        // Step 3
    Set_EW(YELLOW);
    Wait_N_Seconds(2);

      // Step 4
    Set_EW(RED);

      // Step 5
    if (NSLT_SW == 1) {
      // Step 6
        Set_NSLT(GREEN);
        Wait_N_Seconds(6);

         // Step 7
        Set_NSLT(YELLOW);
        Wait_N_Seconds(2);

         // Step 8
        Set_NSLT(RED);
    }

         // Step 9
    Set_NS(GREEN);
    Wait_N_Seconds(8);

        // Step 10
    Set_NS(YELLOW);
    Wait_N_Seconds(2);

       // Step 11
    Set_NS(RED);

      // Step 12
    if (EWLT_SW == 1) {
           // Step 13
        Set_EWLT(GREEN);
        Wait_N_Seconds(8);

           // Step 14
        Set_EWLT(YELLOW);
        Wait_N_Seconds(2);

         // Step 15
        Set_EWLT(RED);
    }

    
}

void main(void)
{
    
    init_UART();                                                     // initializes the UART
    Init_ADC();                                                      // initializes the ADC
    INIT_TRIS();                                                     // initializes the TRIS
    
    while(1)                                                        // infinite loop
    {
        
        SET_ADCON0(0);                                              // sets the ADCON0 register to 0
        int num_step = GET_FULL_ADC();                              // input value from AN0 and stores it as an integer value 
        float voltage_mv = num_step * 4.0;                          // calculates the voltage in millivolts by multiplying the num_step value   
        float voltage_v = voltage_mv / 1000.0;                      // calculates the voltage in volts
       
        
        
        
        
        
        
        
        if(voltage_v < 2.5)                                         // loop to check the voltage to set day or night mode
        {
            
            Day_Mode();
        }
        else{
            
            Night_Mode();
        }
    }

}