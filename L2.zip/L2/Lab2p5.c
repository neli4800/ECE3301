#include <stdio.h>
#include <stdlib.h>
#include <xc.h>
#include <math.h>
#include <p18f4620.h>

#pragma config OSC = INTIO67
#pragma config WDT = OFF
#pragma config LVP = OFF
#pragma config BOREN = OFF


void Delay_One_Sec()                                        // generates time delay  by 1 sec
{
 for(int I=0; I <17000; I++);
 } 

char array[8]={0x85,0xA7,0xE3,0x06,0x21,0xC2,0x62,0X40};    // array of LED colors

void main()
{

        TRISA   = 0xff;                                       // Data input
        TRISB   = 0x00;                                       // data output
        TRISC   = 0x00;                                       //data output
        TRISD   = 0x00;                                       //data output
        ADCON1  = 0x0f;                                      // stores data to PORTC

     while (1)                                              // endless loop
     {   
         for(char i=0; i<8; i++)
         {
            
            PORTC = i;                                      //data output
            
            PORTD = array[i];                               //display all LED colors
            
            Delay_One_Sec();                                //delays LEDs by 1 sec
         }
     }
 } 

