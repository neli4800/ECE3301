#define SEC_LED     PORT?bits.R??       // Defines SEC_LED as 
#define NS_RED      PORT?bits.R??       // Defines NS_RED as 
#define NS_GREEN    PORT?bits.R??       // Defines NS_GREEN as 

#define NSLT_RED    PORT?bits.R??       // Defines NS_LT RED as 
#define NSLT_GREEN  PORT?bits.R??       // Defines NS_LT GREEN as 

#define EW_RED      PORT?bits.R??       // Defines EW_RED as 
#define EW_GREEN    PORT?bits.R??       // Defines EW_GREEN as 

#define EWLT_RED    PORT?bits.R??       // Defines EWLT_RED as 
#define EWLT_GREEN  PORT?bits.R??       // Defines EWLT_GREEN as 

#define NS_LT_SW    PORT?bits.R??       // Defines NS_LT as 
#define NS_PED_SW   PORT?bits.R??       // Defines EW_LT as 

#define EW_LT_SW    PORT?bits.R??       // Defines EW_PED as 

#define MODE_LED    PORT?bits.R??       // Defines MODE_LED as 


