#include <stdio.h>
#include <stdlib.h>
#include <xc.h>
#include <math.h>
#include <p18f4620.h>
#include <usart.h>
#include <string.h>
#include "main.h"
#include "ST7735_TFT.h"
#include "Interrupt.h"

#pragma config OSC = INTIO67
#pragma config WDT = OFF
#pragma config LVP = OFF
#pragma config BOREN = OFF


#define _XTAL_FREQ  8000000             // Set operation for 8 Mhz


void Initialize_Screen();


short Nec_OK = 0;
char Nec_Button;


// colors
#define RD               ST7735_RED
#define BU               ST7735_BLUE
#define GR               ST7735_GREEN
#define MA               ST7735_MAGENTA
#define BK               ST7735_BLACK

#define Circle_Size     20              // Size of Circle for Light
#define Circle_X        60              // Location of Circle
#define Circle_Y        80              // Location of Circle
#define Text_X          52
#define Text_Y          77
#define TS_1            1               // Size of Normal Text
#define TS_2            2               // Size of Big Text


char buffer[31];                        // general buffer for display purpose
char *nbr;                              // general pointer used for buffer
char *txt;

char array1[21]={0xa2, };				// add more value into this array
char txt1[21][4] ={"CH-\0", "CH+\0","VL+\0"," 0 \0",};
										// add more value into this array
int color[21]={RD,};					// add more value into this array

int colord1[21]={0x02, };
int colord2[21]={0x00, };
int colord3[21]={0x00, };

void putch (char c)
{
    while (!TRMT);
    TXREG = c;
}

void init_UART()
{
    OpenUSART (USART_TX_INT_OFF & USART_RX_INT_OFF &
    USART_ASYNCH_MODE & USART_EIGHT_BIT & USART_CONT_RX &
    USART_BRGH_HIGH, 25);
    OSCCON = 0x60;
}


void main()
{
    init_UART();
    OSCCON = 0x70;                          // 8 Mhz
    nRBPU = 0;                              // Enable PORTB internal pull up resistor
	TRISB = 0x07;							//
    TRISC = 0x00;                           // PORTC as output
    TRISD = 0x00;
    ADCON1 = 0x0F;                          //
    Initialize_Screen();					//
	
    Init_Interrupt();
	
	
    TMR1H = 0;                              // Reset Timer1
    TMR1L = 0;                              //
    PIR1bits.TMR1IF = 0;                    // Clear timer 1 interrupt flag
    PIE1bits.TMR1IE = 1;                    // Enable Timer 1 interrupt
    INTCONbits.PEIE = 1;                    // Enable Peripheral interrupt
    INTCONbits.GIE = 1;                     // Enable global interrupts
    Nec_OK = 0;                             // Clear flag
    Nec_code = 0x0;                         // Clear code
    
    while(1)
    {
        if (Nec_OK == 1)
        {
            Nec_OK = 0;

            Enable_INT_Interrupt();
            printf ("NEC_Button = %x \r\n", Nec_Button);  
			
            char found = 0xff;
         
            // add code here to add FOR loop to search for match of Nec_Button with entry of array1
            
            if (found != 0xff) 
            {
				printf ("Key Location = %d \r\n\n", found); 
                fillCircle(Circle_X, Circle_Y, Circle_Size, color[found]); 
                drawCircle(Circle_X, Circle_Y, Circle_Size, ST7735_WHITE);  
                drawtext(Text_X, Text_Y, txt1[found], ST7735_WHITE, ST7735_BLACK,TS_1);
				
				// add code here to output color for the three RGB LEDs
				// add code to turn on KEY PRESSED LEDs
				// generate beep tone
				// wait 1 second
				// remove beep tone
				// turn off KEY PRESSED
            
            }
        }
    }
    }
}

void wait_one_sec()
{
    for (int k=o;k<30000;k++);
}

void Initialize_Screen()
{
    LCD_Reset();
    TFT_GreenTab_Initialize();
    fillScreen(ST7735_BLACK);
  
    /* TOP HEADER FIELD */
    txt = buffer;
    strcpy(txt, "ECE3301L Sp23/S2/T??");  
    drawtext(2, 2, txt, ST7735_WHITE, ST7735_BLACK, TS_1);

    strcpy(txt, "LAB 10 ");  
    drawtext(50, 10, txt, ST7735_WHITE, ST7735_BLACK, TS_1);
}

