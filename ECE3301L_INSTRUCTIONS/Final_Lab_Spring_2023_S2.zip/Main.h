
#define _XTAL_FREQ      8000000

#define ACK             1
#define NAK             0

#define ACCESS_CFG      0xAC
#define START_CONV      0xEE
#define READ_TEMP       0xAA
#define CONT_CONV       0x02


#define FANEN_LED       PORT?bits.R??
#define FAN_EN          PORT?bits.R??
#define FAN_PWM         PORT?bits.R??
#define RTC_ALARM_NOT   PORT?bits.R??

#define Setup_Time_Key        	?
#define Setup_Alarm_Key       	?
#define Setup_Fan_Temp_Key    	?
#define Toggle_Fan_Key      	?
#define Prev            		?
#define Next            		?
#define Minus           		?
#define Plus            		?
#define Ch_Plus            		?
#define Ch_Minus				?



